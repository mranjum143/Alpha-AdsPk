import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index"; // یہاں 'I' بڑا ہونا چاہیے
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";

const App = () => (
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<Index />} />
      <Route path="/auth" element={<Auth />} />
      <Route path="/dashboard" element={<Dashboard />} />
    </Routes>
  </BrowserRouter>
);

export default App;
