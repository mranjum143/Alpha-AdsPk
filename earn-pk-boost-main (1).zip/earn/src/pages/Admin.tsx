// Admin Panel: Deposit & User Management
const AdminDashboard = () => {
  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-2xl font-black mb-6 text-dark-green uppercase">Admin Control Panel</h1>
      
      {/* Pending Deposits Table */}
      <div className="card p-4 overflow-x-auto">
        <h2 className="font-bold mb-4 border-b pb-2">Pending Deposits (Proofs)</h2>
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="bg-gray-50">
              <th className="p-2">User</th>
              <th className="p-2">Amount</th>
              <th className="p-2">Proof</th>
              <th className="p-2">Action</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="p-2">User_01</td>
              <td className="p-2 text-green-600 font-bold">RS. 1000</td>
              <td className="p-2 text-blue-500 underline">View Photo</td>
              <td className="p-2 flex gap-2">
                <button className="bg-green-500 text-white px-3 py-1 rounded text-xs">Approve</button>
                <button className="bg-red-500 text-white px-3 py-1 rounded text-xs">Reject</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Admin Stats */}
      <div className="grid grid-cols-2 gap-4 mt-6">
        <div className="card p-4 bg-white text-center">
          <p className="text-gray-500 text-xs">Total Users</p>
          <p className="text-xl font-bold">124</p>
        </div>
        <div className="card p-4 bg-white text-center">
          <p className="text-gray-500 text-xs">Total Deposits</p>
          <p className="text-xl font-bold text-green-600">RS. 25,000</p>
        </div>
      </div>
    </div>
  );
};
