import React from "react";

const Index = () => {
  return (
    <div style={{ textAlign: "center", padding: "50px" }}>
      <h1>Welcome to Earning Hub</h1>
      <p>آپ کی ویب سائٹ کامیابی سے لائیو ہو چکی ہے!</p>
    </div>
  );
};

// یہ لائن سب سے اہم ہے، اسے لازمی لکھیں
export default Index;
