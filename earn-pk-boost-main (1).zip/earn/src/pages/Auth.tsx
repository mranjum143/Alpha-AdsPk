// Signup Bonus Configuration (100 PKR)
const INITIAL_BALANCE = 100;

// This function handles new user registration
const handleSignUp = async (email, password) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  });

  if (data?.user) {
    // Creating user profile with 100 PKR Bonus
    await supabase.from('profiles').insert([
      { 
        id: data.user.id, 
        balance: INITIAL_BALANCE,
        total_earnings: 0,
        daily_ads_watched: 0
      }
    ]);
    alert("Welcome! 100 PKR Sign-up bonus added to your account.");
  }
};
